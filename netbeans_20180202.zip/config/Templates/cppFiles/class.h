<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

/* 
 * File:        ${NAME}.${EXTENSION}
 * Author:      ${user}
 * Describe:    declaration of ${CLASSNAME}
 *              
 * Created on   ${DATE}, ${TIME}
 */

#ifndef ${GUARD_NAME}
#define	${GUARD_NAME}

#include <iostream>

class ${CLASSNAME} {
    /*predefine here*/
    
    
    /*static member shoud be palced front*/

    
public:
    /*public interface*/
    
    
public:
    /*construction function*/
    
    ${CLASSNAME}();
    
    virtual ~${CLASSNAME}();

    
public:
    /*overloaded operator function*/
    
    friend std::ostream & operator<<(std::ostream & os, const ${CLASSNAME}& orig);
    
    friend std::istream & operator>>(std::istream & is, ${CLASSNAME}& orig);

    
protected:
    /*methods for subclass*/  

    
private:
    /*private method member*/
    
    ${CLASSNAME}(const ${CLASSNAME}& orig);  
    
    ${CLASSNAME}& operator=(const ${CLASSNAME}& orig);
 
    
private:
    /*private data member*/
    

};

#endif	/* ${GUARD_NAME} */

