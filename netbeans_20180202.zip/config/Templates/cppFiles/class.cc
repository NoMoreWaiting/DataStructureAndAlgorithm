<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

/* 
 * File:        ${NAME}.${EXTENSION}
 * Author:      ${user}
 * Describe:    implementation of ${CLASSNAME}
 *              
 * Created on   ${DATE}, ${TIME}
 */

#include ${QUOTES}${NAME}.${DEFAULT_HEADER_EXT}${QUOTES}

/*static member here*/



/*construction function*/

${CLASSNAME}::${CLASSNAME}() {
    
}

${CLASSNAME}::~${CLASSNAME}() {
    
}

${CLASSNAME}::${CLASSNAME}(const ${CLASSNAME}& orig) {
    
}



/*overloaded operator function*/

${CLASSNAME}& ${CLASSNAME}::operator=(const ${CLASSNAME}& orig) {
    
}

std::ostream & operator<<(std::ostream & os, const ${CLASSNAME}& orig){
    
}

std::istream & operator>>(std::istream & is, ${CLASSNAME}& orig){
    
}



/*public interface*/ 



/*protected method*/ 



/*private method*/