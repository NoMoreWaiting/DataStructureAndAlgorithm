<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

/* 
 * File:        ${NAME}.${EXTENSION}
 * Author:      ${user}
 * Describe:    
 * Created on   ${DATE}, ${TIME}
 */

#include <iostream>

using namespace std;

/**
 * main 函数
 * para:    argc
 * para:    argv
 * return:  int, 0 is ok, other is abnormal
 */
int main(int argc, char** argv) {
    
    return 0;
}

