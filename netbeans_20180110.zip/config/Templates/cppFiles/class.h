<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

/* 
 * File:        ${NAME}.${EXTENSION}
 * Author:      ${user}
 * Describe:    declaration of ${CLASSNAME}
 *              
 * Created on   ${DATE}, ${TIME}
 */

#ifndef ${GUARD_NAME}
#define	${GUARD_NAME}

#include <iostream>

class ${CLASSNAME} {
/*predefine here*/  /*static member shoud be palced front*/
    

private:
    /*private data member*/
    
private:
    /*private method member*/
    ${CLASSNAME}& operator=(const ${CLASSNAME}& orig);
    ${CLASSNAME}(const ${CLASSNAME}& orig);
  
protected:
/*methods for subclass*/  

public:
    /*construction function*/
    
    ${CLASSNAME}();

    virtual ~${CLASSNAME}();

public:
/*overloaded operator function*/
        
    friend std::ostream & operator<<(std::ostream & os, const ${CLASSNAME}& orig);
    friend std::istream & operator>>(std::istream & is, ${CLASSNAME}& orig);

/*public interface*/        
public:

};

#endif	/* ${GUARD_NAME} */

