<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

/* 
 * File:        ${NAME}.${EXTENSION}
 * Author:      ${user}
 * Describe:    implementation of ${CLASSNAME}
 *              
 * Created on   ${DATE}, ${TIME}
 */

#include ${QUOTES}${NAME}.${DEFAULT_HEADER_EXT}${QUOTES}

/*static member here*/


/*methods for subclass*/ 


/*construction function*/
${CLASSNAME}::${CLASSNAME}() {
    
}

${CLASSNAME}::~${CLASSNAME}() {
    
}

/*overloaded operator function*/

${CLASSNAME}::${CLASSNAME}(const ${CLASSNAME}& orig) {
    
}

${CLASSNAME}& ${CLASSNAME}::operator=(const ${CLASSNAME}& orig) {
    
}

std::ostream & operator<<(std::ostream & os, const ${CLASSNAME}& orig){
    
}

std::istream & operator>>(std::istream & is, ${CLASSNAME}& orig){
    
}

/*public interface*/ 
